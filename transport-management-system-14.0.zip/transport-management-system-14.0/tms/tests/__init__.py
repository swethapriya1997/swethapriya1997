# Copyright 2016, Jarsa Sistemas, S.A. de C.V.
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).

from . import test_fleet_vehicle
from . import test_fleet_vehicle_log_fuel
from . import test_hr_employee
from . import test_product_template
from . import test_tms_advance
from . import test_tms_event
from . import test_tms_expense
from . import test_tms_expense_line
from . import test_tms_expense_loan
from . import test_tms_factor
from . import test_tms_place
from . import test_tms_route
from . import test_tms_transportable
from . import test_tms_travel
from . import test_tms_waybill
from . import test_tms_waybill_line
from . import test_tms_waybill_transportable_line
